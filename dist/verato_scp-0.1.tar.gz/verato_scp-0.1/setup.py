from setuptools import setup, find_packages
import sys, os

setup(name='verato_scp',
      version='0.1',
      description='Utility to help scp file with commands and run on host (local -> jump -> provisioner -> host)',
      url='https://github.com/olzhas23/verato_scp.git',
      author='Olzhas Shaikenov',
      author_email='olzhas.shaikenov@verato.com',
      license='MIT',
      packages=['verato_scp'],
      scripts = ['vscp'],
      zip_safe=False)
